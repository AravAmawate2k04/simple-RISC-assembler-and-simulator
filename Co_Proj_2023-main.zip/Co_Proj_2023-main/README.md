# Co_Proj_2023
This is our project whihc have assembler using python we created this contributed by Aditya Dixit, Kartvaya ,Arav. It reads the file look for errors and at the end add the codes to opc.txt and read the text from assm_prog.txt. But after the updates it reads from sys.stdin.
